#include <SDL2/SDL.h>
#include <list>
#include "Blocos/Bloco.h"
#include "Blocos/BlocoBase.h"
#include "Constants.h"
#include "Utils/Utils.h"

int main(int argc, char* argv[]) {
    SDL_Window* janela = NULL;
    SDL_Renderer* renderer = NULL;

    SDL_Init(SDL_INIT_VIDEO);
    janela = SDL_CreateWindow("Tower Building", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED,
                              LARGURA, ALTURA, SDL_WINDOW_SHOWN);
    renderer = SDL_CreateRenderer(janela, -1, SDL_RENDERER_ACCELERATED);

    BlocoBase blocoBase(LARGURA / 2 - BLOCO_WIDTH / 2, 666, 0, 255, 0);
    std::list<Bloco> blocos;
    blocos.emplace_back(LARGURA / 2 - BLOCO_WIDTH / 2, 100, random_num(), random_num(), random_num());

    bool continua = true;
    SDL_Event evento;

    while (continua) {
        while (SDL_PollEvent(&evento)) {
            if (evento.type == SDL_QUIT) {
                continua = false;
            } else if (evento.type == SDL_KEYDOWN) {
                if (evento.key.keysym.sym == SDLK_SPACE) {
                    // Move o bloco para baixo até atingir a parte inferior da tela
                    while (!blocos.front().naParteInferior()) {
                        blocos.front().moverBaixo();
                        SDL_SetRenderDrawColor(renderer, 133, 193, 233, SDL_ALPHA_OPAQUE);
                        SDL_RenderClear(renderer);
                        for (const auto& bloco : blocos) {
                            bloco.renderizar(renderer);
                            blocoBase.renderizar(renderer);
                        }
                        SDL_RenderPresent(renderer);
                        SDL_Delay(5);

                        // Verifica colisão entre o primeiro bloco e o bloco base
                        if (colisaoBase(blocos.front(), blocoBase)) {
                            // Define a posição do bloco para que ele fique em cima do bloco base
                            blocos.front().definirPosicao(blocos.front().getX(), blocoBase.getY() - BLOCO_HEIGHT);
                            break;
                        }

                        // Verifica colisão entre o bloco que está descendo e os blocos já empilhados
                        bool colidiu = false;
                        for (auto it = std::next(blocos.begin()); it != blocos.end(); ++it) {
                            if (colisao(blocos.front(), *it)) {
                                blocos.front().definirPosicao(blocos.front().getX(), it->getY() - BLOCO_HEIGHT);
                                colidiu = true;
                                break;
                            }
                        }
                        if (colidiu) {
                            break;
                        }
                    }

                    // Adiciona o bloco atual à pilha de blocos
                    blocos.push_back(blocos.front());
                    // Adiciona um novo bloco na parte de cima
                    // Utilizei random_num para gerar com cores diferentes
                    blocos.front() = Bloco(LARGURA / 2 - BLOCO_WIDTH / 2, 100, random_num(), random_num(), random_num());
                }
            }
        }

        SDL_SetRenderDrawColor(renderer, 133, 193, 233, SDL_ALPHA_OPAQUE);
        SDL_RenderClear(renderer);

        // Renderiza todos os blocos
        for (const auto& bloco : blocos) {
            bloco.renderizar(renderer);
        }
        blocoBase.renderizar(renderer);

        SDL_RenderPresent(renderer);
        SDL_Delay(10);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(janela);
    SDL_Quit();
    return 0;
}

