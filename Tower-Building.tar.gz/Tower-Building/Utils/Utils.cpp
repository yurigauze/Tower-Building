#include "Utils.h"
#include <random>

int random_num() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 255);
    return dis(gen);
}

bool colisaoBase(const Bloco& bloco, const BlocoBase& blocoBase) {
    if (bloco.getX() + BLOCO_WIDTH <= blocoBase.getX() || blocoBase.getX() + BLOCO_WIDTH <= bloco.getX()) {
        return false;
    }
   
    if (bloco.getY() + BLOCO_HEIGHT <= blocoBase.getY() || blocoBase.getY() + BLOCO_HEIGHT <= bloco.getY()) {
        return false;
    }

    return true;
}

bool colisao(const Bloco& bloco1, const Bloco& bloco2) {
    if (bloco1.getX() + BLOCO_WIDTH <= bloco2.getX() || bloco2.getX() + BLOCO_WIDTH <= bloco1.getX()) {
        return false;
    }
   
    if (bloco1.getY() + BLOCO_HEIGHT <= bloco2.getY() || bloco2.getY() + BLOCO_HEIGHT <= bloco1.getY()) {
        return false;
    }

    return true;
}

