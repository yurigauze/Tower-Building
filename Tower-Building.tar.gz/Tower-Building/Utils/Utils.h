#ifndef UTILS_H
#define UTILS_H

#include "../Blocos/Bloco.h"
#include "../Blocos/BlocoBase.h"

int random_num();
bool colisaoBase(const Bloco& bloco, const BlocoBase& blocoBase);
bool colisao(const Bloco& bloco1, const Bloco& bloco2);

#endif 

