#ifndef CONSTANTS_H
#define CONSTANTS_H

const int LARGURA = 600;
const int ALTURA = 850;
const int BLOCO_WIDTH = 188;
const int BLOCO_HEIGHT = 134;
const int MOVE_AMOUNT = 15; // Quantidade de pixels que o bloco se move a cada quadro

#endif

