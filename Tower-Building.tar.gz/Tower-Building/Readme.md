
# Tower Building - EM DESENVOLVIMENTO

Tower Building é um teste de desenvolvimento utilizando C++, utilizando SDL2 nas materias de Projeto Avançado de Software e Topicos em Computação

================== Em desenvolvimento ==================

### Objetivo do Tower Building
O objetivo do jogo é construindo um prédio através de posicionar andares suspensos por um guindate. A montade de pontução, o guindate se movimenta mais rápido dificultando a contruição do predio.
